import pygame
import pygame.gfxdraw
import math
import time

# Global constants
player1_score = 0
player2_score = 0
# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (200,200,0)
GOLD = (205,149,12)

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600


class Player(pygame.sprite.Sprite):

    # -- Methods
    def __init__(self, radius, color):

        # Call the parent's constructor
        super().__init__()
        self.radius = radius
        self.color = color
        # self.gravity = gravity

        self.image = pygame.Surface([self.radius*2, self.radius*2], pygame.SRCALPHA)
        pygame.gfxdraw.aacircle(self.image, self.radius, self.radius, self.radius, self.color)
        pygame.gfxdraw.filled_circle(self.image, self.radius, self.radius, self.radius, self.color)


        self.rect = self.image.get_rect()

        # Set speed vector of player
        self.change_x = 0
        self.change_y = 0

        # List of sprites we can bump against
        self.level = None

    def update(self):
        # Gravity
        self.calc_grav()

        # Move left/right
        self.rect.x += self.change_x

        # See if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:
            # If we are moving right,
            # set our right side to the left side of the item we hit
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                # Otherwise if we are moving left, do the opposite.
                self.rect.left = block.rect.right

        # Move up/down
        self.rect.y += 3*self.change_y

        # Check and see if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:

            # Reset our position based on the top/bottom of the object.
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom

            # Stop our vertical movement
            self.change_y = 0

    def calc_grav(self):
        if self.change_y == 0:
            self.change_y = 1
        else:
            self.change_y += .3

        # See if we are on the ground.
        if self.rect.y >= SCREEN_HEIGHT - self.rect.height and self.change_y >= 0:
            self.change_y = 0
            self.rect.y = SCREEN_HEIGHT - self.rect.height

    def jump(self):

        # move down a bit and see if there is a platform below us.
        # Move down 2 pixels because it doesn't work well if we only move down
        # 1 when working with a platform moving down.
        self.rect.y += 1
        platform_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False, pygame.sprite.collide_circle)
        self.rect.y -= 1

        # If it is ok to jump, set our speed upwards
        if len(platform_hit_list) > 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.change_y = -5

    # Player-controlled movement:
    def go_left(self):
        self.change_x = -5

    def go_right(self):
        self.change_x = 5

    def stop(self):
        self.change_x = 0

class Ball(pygame.sprite.Sprite):

    def __init__(self, radius):

        super().__init__()
        self.radius = radius

        self.image = pygame.Surface([self.radius*2, self.radius*2], pygame.SRCALPHA)
        pygame.gfxdraw.aacircle(self.image, self.radius, self.radius, self.radius, GREEN)
        pygame.gfxdraw.filled_circle(self.image, self.radius, self.radius, self.radius, GREEN)

        self.rect = self.image.get_rect()

        # Set speed vector of ball_pos
        self.bchange_x = 5
        self.bchange_y = 0

        # List of sprites we can bump against
        self.level = None

    def update(self):

        self.calc_grav()

        # hreyfing boltans hægri/vinstri
        self.rect.x += self.bchange_x

        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:
            # If we are moving right,
            # set our right side to the left side of the item we hit
            if self.bchange_x > 0:
                self.bchange_x *= -0.8
                self.rect.right = block.rect.left
            elif self.bchange_x < 0:
                self.bchange_x *= -0.8
                # Otherwise if we are moving left, do the opposite.
                self.rect.left = block.rect.right

        player_hit_list = pygame.sprite.spritecollide(self, self.level.enemy_list, False, pygame.sprite.collide_circle)
        for player in player_hit_list:
            if self.bchange_x > 0:
                self.rect.right = player.rect.left
                self.bchange_x *= -1
                #self.rect.right = player.rect.left
            elif self.bchange_x < 0:
                self.rect.left = player.rect.right
                self.bchange_x *= -1
                #self.rect.left = player.rect.right

        self.rect.y += self.bchange_y

        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:

            if self.bchange_y > 0:
                self.bchange_y *= -0.8
                self.rect.bottom = block.rect.top
            elif self.bchange_y < 0:
                self.bchange_y *= -0.8
                self.rect.top = block.rect.bottom

        player_hit_list = pygame.sprite.spritecollide(self, self.level.enemy_list, False, pygame.sprite.collide_circle)
        for player in player_hit_list:
            if self.bchange_y > 0:
                self.rect.bottom = player.rect.top
                self.bchange_y *= -1
                #self.rect.bottom = player.rect.top
            elif self.bchange_y < 0:
                self.rect.top = player.rect.bottom
                self.bchange_y *= -1
                #self.rect.top = player.rect.bottom

        if self.rect.right > SCREEN_WIDTH:
            self.bchange_x *= -1
        if self.rect.left < 0:
            self.bchange_x *= -1


    def calc_grav(self):
        if self.bchange_y == 0:
            self.bchange_y = 1
        else:
            self.bchange_y += .95

        # See if we are on the ground.
        if self.rect.y >= SCREEN_HEIGHT - self.rect.height and self.bchange_y >= 0:
            self.bchange_y *= -0.78
            self.rect.y = SCREEN_HEIGHT - self.rect.height

class GOALS(pygame.sprite.Sprite):
    def __init__(self, width, height):

        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(YELLOW)

        self.rect = self.image.get_rect()


class Platform(pygame.sprite.Sprite):

    def __init__(self, width, height):
        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(WHITE)

        self.rect = self.image.get_rect()

class CirclePlatform(pygame.sprite.Sprite):

    def __init__(self, radius):
        super().__init__()

        self.image = pygame.Surface([radius*2, radius*2], pygame.SRCALPHA)
        pygame.gfxdraw.aacircle(self.image, radius, radius, radius, WHITE)
        pygame.gfxdraw.filled_circle(self.image, radius, radius, radius, WHITE)

        self.rect = self.image.get_rect()


class Level(object):

    def __init__(self, player1, player2, ball):
        self.platform_list = pygame.sprite.Group()
        self.enemy_list = pygame.sprite.Group()
        self.ball_list = pygame.sprite.Group()
        self.goal_list = pygame.sprite.Group()
        self.player1 = player1
        self.player2 = player2

        self.enemy_list.add(player1)
        self.enemy_list.add(player2)

        self.background = None

    # Update everythign on this level
    def update(self):
        self.platform_list.update()
        self.enemy_list.update()
        self.ball_list.update()
        self.goal_list.update()

    def draw(self, screen):

        # Draw all the sprite lists that we have
        self.platform_list.draw(screen)
        self.enemy_list.draw(screen)
        self.ball_list.draw(screen)
        self.goal_list.draw(screen)



# Create platforms for the level
class Level_01(Level):

    def __init__(self, player1, player2, ball):

        # Call the parent constructor
        Level.__init__(self, player1, player2, ball)
        self.player1 = player1
        self.player2 = player2
        self.ball = ball
        self.player1_score = 0
        self.player2_score = 0

        # Array with width, height, x, and y of platform
        level = [[120, 10, (SCREEN_WIDTH  - 120), (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3)],
                 [120, 10, 0, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3)]
                 ]

        goals = [[75, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 - 10), (SCREEN_WIDTH  - 75), (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 + 10)],
                 [75, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 - 10), 0, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 + 10)]
                 ]
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player1 = self.player1
            block.player2 = self.player2
            block.ball = self.ball
            self.platform_list.add(block)



        for platform in goals:
            goal = GOALS(platform[0], platform[1])
            goal.rect.x = platform[2]
            goal.rect.y = platform[3]
            self.goal_list.add(goal)

    def update(self):
        self.platform_list.update()
        self.enemy_list.update()
        self.ball_list.update()
        self.goal_list.update()

        goals_list = pygame.sprite.spritecollide(self.ball, self.goal_list, False)
        for goal in goals_list:
            if self.ball.rect.center[0] > SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player2_score += 1
                #Level_01.score(self.player1_score, self.player2_score)

            elif self.ball.rect.center[0] < SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player1_score += 1

            Level_01.score(self.player1_score, self.player2_score)
            # Köllum í score fall í level 1 til að uppfæra global breytur

            #print('Staðan er:')
            return(self.player1_score, self.player2_score)

    def score(thing1, thing2):
        player1_score = thing1 #self.player1_score
        player2_score = thing2 #self.player2_score
        print ('Score in game 1 is:')
        #print('Staðan í leik 1 er:')
        print(player1_score ,player2_score)
        '''upfærum stöðu leiksins og skrifum í score1.txt'''
        score = str(player1_score) + str(player2_score)
        file = open('score1.txt', 'w')
        file.write(score)
        return(player1_score)
        file.close()


class Level_02(Level):

    def __init__(self, player1, player2, ball):

        # Call the parent constructor
        Level.__init__(self, player1, player2, ball)
        self.player1 = player1
        self.player2 = player2
        self.ball = ball
        self.player1_score = 0
        self.player2_score = 0

        goals = [[75, 100, (SCREEN_WIDTH  - 75), (SCREEN_HEIGHT - 100)],
                 [75, 100, 0, (SCREEN_HEIGHT - 100)]
                 ]

        for platform in goals:
            goal = GOALS(platform[0], platform[1])
            goal.rect.x = platform[2]
            goal.rect.y = platform[3]
            self.goal_list.add(goal)

    def update(self):
        self.platform_list.update()
        self.enemy_list.update()
        self.ball_list.update()
        self.goal_list.update()

        goals_list = pygame.sprite.spritecollide(self.ball, self.goal_list, False)
        for goal in goals_list:
            if self.ball.rect.center[0] > SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player2_score += 1
                #Level_01.score(self.player1_score, self.player2_score)

            elif self.ball.rect.center[0] < SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player1_score += 1

            Level_02.score2(self.player1_score, self.player2_score)
            # Köllum í score fall í level 1 til að uppfæra global breytur

            #print('prentum self.player score i naestu linu')
            return(self.player1_score, self.player2_score)

    def score2(thing1, thing2):
        player1_score = thing1 #self.player1_score
        player2_score = thing2 #self.player2_score
        print ('Score in game 2 is:')
        #print('Staðan í leik 2 er:')
        print(player1_score ,player2_score)
        '''upfærum stöðu leiksins og skrifum í score2.txt'''
        score2 = str(player1_score) + str(player2_score)
        file = open('score2.txt', 'w')
        file.write(score2)
        file.close()

class Level_03(Level):

    def __init__(self, player1, player2, ball):

        # Call the parent constructor
        Level.__init__(self, player1, player2, ball)
        self.player1 = player1
        self.player2 = player2
        self.ball = ball
        self.player1_score = 0
        self.player2_score = 0

        # Array with width, height, x, and y of platform
        level = [[10, SCREEN_HEIGHT//10*3, 120, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3)],
                 [10, SCREEN_HEIGHT//10*3, SCREEN_WIDTH-130, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3)]
                 ]
        goals = [[120, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3), (SCREEN_WIDTH  - 120), (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 + 10)],
                 [120, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3), 0, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 + 10)]
                 ]
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player1 = self.player1
            block.player2 = self.player2
            block.ball = self.ball
            self.platform_list.add(block)

        for platform in goals:
            goal = GOALS(platform[0], platform[1])
            goal.rect.x = platform[2]
            goal.rect.y = platform[3]
            self.goal_list.add(goal)

    def update(self):
        self.platform_list.update()
        self.enemy_list.update()
        self.ball_list.update()
        self.goal_list.update()

        goals_list = pygame.sprite.spritecollide(self.ball, self.goal_list, False)
        for goal in goals_list:
            if self.ball.rect.center[0] > SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player2_score += 1
                #Level_01.score(self.player1_score, self.player2_score)

            elif self.ball.rect.center[0] < SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player1_score += 1

            Level_03.score3(self.player1_score, self.player2_score)
            # Köllum í score fall í level 1 til að uppfæra global breytur

            #print('prentum self.player score i naestu linu')
            return(self.player1_score, self.player2_score)

    def score3(thing1, thing2):
        player1_score = thing1 #self.player1_score
        player2_score = thing2 #self.player2_score
        print ('Score in game 3 is:')
        #print('Staðan í leik 3 er:')
        print(player1_score ,player2_score)
        '''upfærum stöðu leiksins og skrifum í score3.txt'''
        score3 = str(player1_score) + str(player2_score)
        file = open('score3.txt', 'w')
        file.write(score3)
        file.close()

class Level_04(Level):

    def __init__(self, player1, player2, ball):

        # Call the parent constructor
        Level.__init__(self, player1, player2, ball)
        self.player1 = player1
        self.player2 = player2
        self.ball = ball
        self.player1_score = 0
        self.player2_score = 0

        # Array with width, height, x, and y of platform
        level = [[120, 10, (SCREEN_WIDTH  - 120), (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3)],
                 [120, 10, 0, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3)],
                 [10, SCREEN_HEIGHT//10*2, SCREEN_WIDTH//2+5, SCREEN_HEIGHT - SCREEN_HEIGHT//10*2]
                 ]
        goals = [[75, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 - 10), (SCREEN_WIDTH  - 75), (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 + 10)],
                 [75, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 - 10), 0, (SCREEN_HEIGHT - SCREEN_HEIGHT//10*3 + 10)]
                 ]
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player1 = self.player1
            block.player2 = self.player2
            block.ball = self.ball
            self.platform_list.add(block)

        for platform in goals:
            goal = GOALS(platform[0], platform[1])
            goal.rect.x = platform[2]
            goal.rect.y = platform[3]
            self.goal_list.add(goal)

    def update(self):
        self.platform_list.update()
        self.enemy_list.update()
        self.ball_list.update()
        self.goal_list.update()

        goals_list = pygame.sprite.spritecollide(self.ball, self.goal_list, False)
        for goal in goals_list:
            if self.ball.rect.center[0] > SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player2_score += 1
                #Level_01.score(self.player1_score, self.player2_score)

            elif self.ball.rect.center[0] < SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player1_score += 1

            Level_04.score4(self.player1_score, self.player2_score)
            # Köllum í score fall í level 1 til að uppfæra global breytur

            #print('prentum self.player score i naestu linu')
            return(self.player1_score, self.player2_score)

    def score4(thing1, thing2):
        player1_score = thing1 #self.player1_score
        player2_score = thing2 #self.player2_score
        print ('Score in game 4 is:')
        #print('Staðan í leik 4 er:')
        print(player1_score ,player2_score)
        '''upfærum stöðu leiksins og skrifum í score4.txt'''
        score4 = str(player1_score) + str(player2_score)
        file = open('score3.txt', 'w')
        file.write(score4)
        file.close()

class Level_05(Level):

    def __init__(self, player1, player2, ball):

        # Call the parent constructor
        Level.__init__(self, player1, player2, ball)
        self.player1 = player1
        self.player2 = player2
        self.ball = ball
        self.player1_score = 0
        self.player2_score = 0

        # Array with width, height, x, and y of platform
        level = [[15, 50, (SCREEN_WIDTH  - 15), (SCREEN_HEIGHT - 40)],
                 [15, 50, (SCREEN_WIDTH  - 90), (SCREEN_HEIGHT - 40)],
                 [15, 50, 0, (SCREEN_HEIGHT - 40)],
                 [15, 50, 75, (SCREEN_HEIGHT - 40)]
                 ]

        levelCircle = [40, (SCREEN_WIDTH // 2 - 20), (SCREEN_HEIGHT - SCREEN_HEIGHT // 3)]
        goals = [[60, 20, (SCREEN_WIDTH  - 75), (SCREEN_HEIGHT - 20)],
                 [60, 20, 15, (SCREEN_HEIGHT - 20)]
                 ]
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player1 = self.player1
            block.player2 = self.player2
            block.ball = self.ball
            self.platform_list.add(block)


        Circleblock = CirclePlatform(levelCircle[0])
        Circleblock.rect.x = levelCircle[1]
        Circleblock.rect.y = levelCircle[2]
        Circleblock.player1 = self.player1
        Circleblock.player2 = self.player2
        Circleblock.ball = self.ball
        self.platform_list.add(Circleblock)

        for platform in goals:
            goal = GOALS(platform[0], platform[1])
            goal.rect.x = platform[2]
            goal.rect.y = platform[3]
            self.goal_list.add(goal)

    def update(self):
        self.platform_list.update()
        self.enemy_list.update()
        self.ball_list.update()
        self.goal_list.update()

        goals_list = pygame.sprite.spritecollide(self.ball, self.goal_list, False)
        for goal in goals_list:
            if self.ball.rect.center[0] > SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player2_score += 1
                #Level_01.score(self.player1_score, self.player2_score)

            elif self.ball.rect.center[0] < SCREEN_WIDTH // 2:
                Start_position(self.player1, self.player2, self.ball)
                self.player1_score += 1

            Level_05.score5(self.player1_score, self.player2_score)
            # Köllum í score fall í level 1 til að uppfæra global breytur

            #print('prentum self.player score i naestu linu')
            return(self.player1_score, self.player2_score)

    def score5(thing1, thing2):
        player1_score = thing1 #self.player1_score
        player2_score = thing2 #self.player2_score
        print ('Score in game 5 is:')
        #print('Staðan í leik 5 er:')
        print(player1_score ,player2_score)
        '''upfærum stöðu leiksins og skrifum í score5.txt'''
        score5 = str(player1_score) + str(player2_score)
        file = open('score5.txt', 'w')
        file.write(score5)
        file.close()

class Start_position(pygame.sprite.Sprite):

    def __init__(self, player1, player2, ball):


        ball.rect.x = SCREEN_WIDTH // 2
        ball.rect.y = SCREEN_HEIGHT // 2

        player1.rect.x = SCREEN_WIDTH - SCREEN_WIDTH // 4
        player1.rect.y = SCREEN_HEIGHT - player1.rect.height
        player2.rect.x = SCREEN_WIDTH // 4
        player2.rect.y = SCREEN_HEIGHT - player2.rect.height


class classmain(object):

    def __init__(self, client1):
        self.client1 = client1


    def main(self):
        #player1_score = self.player1_score
        """ Main Program """
        pygame.init()

        # Set the height and width of the screen
        size = [SCREEN_WIDTH, SCREEN_HEIGHT]
        screen = pygame.display.set_mode(size)

        pygame.display.set_caption("Kúlukallar")

        # Create all the levels
        level_list = []
        current_level_no = 0
        scor1 = 0
        scor2 = 0

        while current_level_no <= 4:
            if current_level_no == 0:
                player1 = Player(30, BLUE)
                player2 = Player(30, RED)
                ball = Ball(20)
                level_list.append(Level_01(player1, player2, ball) )
                background = pygame.image.load("vollur1.png")
                print('LEIKUR 1')

            elif current_level_no == 1:
                player1 = Player(40, BLUE)
                player2 = Player(40, RED)
                ball = Ball(15)
                level_list.append(Level_02(player1, player2, ball) )
                background = pygame.image.load('vollur2.png')
                print('\n'+'LEIKUR 2')

            elif current_level_no == 2:
                player1 = Player(20, BLUE)
                player2 = Player(20, RED)
                ball = Ball(30)
                level_list.append(Level_03(player1, player2, ball) )
                background = pygame.image.load('vollur3.png')
                print('\n'+'LEIKUR 3')

            elif current_level_no == 3:
                player1 = Player(20, BLUE)
                player2 = Player(20, RED)
                ball = Ball(30)
                level_list.append(Level_04(player1, player2, ball) )
                background = pygame.image.load('vollur4.png')
                print('\n'+'LEIKUR 4')

            elif current_level_no == 4:
                player1 = Player(25, BLUE)
                player2 = Player(25, RED)
                ball = Ball(15)
                level_list.append(Level_05(player1, player2, ball) )
                background = pygame.image.load('vollur5.png')
                print('\n'+'LEIKUR 5')

            current_level = level_list[current_level_no]

            active_sprite_list = pygame.sprite.Group()
            ball_sprite = pygame.sprite.Group()
            player1.level = current_level
            player2.level = current_level
            ball.level = current_level

            start_pos = Start_position(player1, player2, ball)
            #active_sprite_list.add(ball)
            active_sprite_list.add(player1)
            active_sprite_list.add(player2)
            ball_sprite.add(ball)

            # Loop until the user clicks the close button.
            done = False

            # Used to manage how fast the screen updates
            clock = pygame.time.Clock()

            font = pygame.font.SysFont(None, 50)
            Game_time_sec = 180

            # -------- Main Program Loop -----------
            while not done:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        done = True
                        quit()

                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_LEFT:
                            player1.go_left()
                        if event.key == pygame.K_RIGHT:
                            player1.go_right()
                        if event.key == pygame.K_UP:
                            player1.jump()
                        if event.key == pygame.K_a:
                            player2.go_left()
                        if event.key == pygame.K_d:
                            player2.go_right()
                        if event.key == pygame.K_w:
                            player2.jump()

                    if event.type == pygame.KEYUP:
                        if event.key == pygame.K_LEFT and player1.change_x < 0:
                            player1.stop()
                        if event.key == pygame.K_RIGHT and player1.change_x > 0:
                            player1.stop()
                        if event.key == pygame.K_a and player2.change_x < 0:
                            player2.stop()
                        if event.key == pygame.K_d and player2.change_x > 0:
                            player2.stop()

                time_passed = clock.tick(60)
                time_passed_seconds = time_passed/1000 #This is so we can set time_left to seconds and not have to use milliseconds
                Game_time_sec -= time_passed_seconds
                # Update the player.
                active_sprite_list.update()

                ball_sprite.update()

                # Update items in the level
                current_level.update()

                # If the player gets near the right side, shift the world left (-x)
                if player1.rect.right > SCREEN_WIDTH:
                    player1.rect.right = SCREEN_WIDTH
                if player2.rect.right > SCREEN_WIDTH:
                    player2.rect.right = SCREEN_WIDTH


                # If the player gets near the left side, shift the world right (+x)
                if player1.rect.left < 0:
                    player1.rect.left = 0
                if player2.rect.left < 0:
                    player2.rect.left = 0

                # TEIKNUM ALLT
                screen.blit(background, (0,0))
                current_level.draw(screen)
                active_sprite_list.draw(screen)
                ball_sprite.draw(screen)

                time_left_rendered = font.render("{:01}:{:02}".format(int((Game_time_sec)/60), int(Game_time_sec%60)), False, BLACK)
                screen.blit(time_left_rendered, (360,10))
                #score1 = font.render(str(scor1), False, WHITE)
                Team1Wins = font.render(str(scor1), False, BLACK)
                Team2Wins = font.render(str(scor2), False, BLACK)
                screen.blit(Team2Wins, (0,0))
                screen.blit(Team1Wins, (SCREEN_WIDTH-20,0))


                pygame.display.flip()


                if Game_time_sec < 170:
                    ''' lengd leikja ákvarðast af tölunni hér að ofan í if setningunni'''

                    if current_level_no == 0:
                        scores = open('score1.txt', 'r')
                    if current_level_no == 1:
                        scores = open('score2.txt', 'r')
                    if current_level_no == 2:
                        scores = open('score3.txt', 'r')
                    if current_level_no == 3:
                        scores = open('score4.txt', 'r')
                    if current_level_no == 4:
                        scores = open('score5.txt', 'r')

                    for line in scores:
                        data = line
                        #print(data)
                        scor1 = data[0]
                        scor2 = data[1]

                    score = str(scor1) + str(scor2)
                    print('we want to send this below')
                    print(score)
                    self.client1.s2.send(bytes(score, 'utf-8'))
                    # taka við winner og uppfæra Wins í skjá skor1 og skor2
                    buf = self.client1.s.recv(1024)
                    msg = buf.decode('utf-8')
                    print(msg)
                    scor1 = msg[0]
                    scor2 = msg[1]

                    if len(msg) > 3:
                        Winner = font.render(msg, False, GOLD)
                        Trophy = pygame.image.load('Trophy.png')
                        screen.blit(Trophy, (0,0))
                        screen.blit(Winner, (0,0))
                        pygame.display.flip()
                        time.sleep(8)
                        pygame.quit()
                        quit()



                    current_level_no += 1

                    break


    pygame.quit()
