import socket
import select
import time
from subprocess import call

class client(object):

    def __init__(self,s, s2):
        self.s = s
        self.s2 = s2
        #self.s3 = s3

    def start_screen(self):
        #print('start_screen yes')
        import HMintro2



    def start_game(self, bar, play):
        #print("yes2")
        self.s2.send(bytes(bar, 'utf-8'))
        from ballboys3 import classmain
        main2 = classmain(play)
        main2.main()



def main():
    #call('clear')

    s = socket.socket(socket.AF_INET , socket. SOCK_STREAM)
    s2 = socket.socket(socket.AF_INET , socket. SOCK_STREAM)
    s.connect(('localhost', 3333))
    s2.connect(('localhost', 3111))

    play = client(s,s2)
    play.start_screen()
    f = open('leikmenn1.txt', 'r')
    print('\n' + 'players info')
    listi = f.readlines()
    for thing in listi:
        print(thing)
    #nation1 = listi[0]
    #player1 = listi[1]
    #nation2 = listi[2]
    #player2 = listi[3]
    #print(player1)
    #print(player2)
    #bar = player1

    play.start_game('gylfi', play)



if __name__ == '__main__':
    main()
