import pygame
import time
import random
from ballboys3 import classmain
from Server import server
pygame.init()

display_width = 800
display_height = 600

gameDisplay = pygame.display.set_mode((display_width,display_height))


pygame.display.set_caption('Ísland á HM')

white = (255,255,255)
black = (0,0,0)
yellow = (200,200,0)
light_yellow =(255, 255,0)

red = (200,0,0)
light_red = (255,0,0)

green = (34,177,76)
light_green = (0,255,0)

blue = (0,50,255)
light_blue = (0,155,255)

BLUE = (0,207,255)
light_BLUE = (0,255,255)

pink = (255, 51,153)
light_pink = (255,153, 204)

clock = pygame.time.Clock()

smallfont = pygame.font.SysFont("comicsansms", 25)
medfont = pygame.font.SysFont("comicsansms", 50)
largefont = pygame.font.SysFont("comicsansms", 85)

gylfi = pygame.image.load('gylfi1.png')
johann = pygame.image.load('johann.png')
messi = pygame.image.load('messi.png')
aguero = pygame.image.load('aguero.png')
modric = pygame.image.load('modric.png')
mandzukic = pygame.image.load('mandzukic.png')
moses = pygame.image.load('moses.png')
iwobi = pygame.image.load('iwobi.png')


fifa = pygame.image.load('fifa.png')


def text_objects(text, color,size = "small"):

    if size == "small":
        textSurface = smallfont.render(text, True, color)
    if size == "medium":
        textSurface = medfont.render(text, True, color)
    if size == "large":
        textSurface = largefont.render(text, True, color)

    return textSurface, textSurface.get_rect()

def text_to_button(msg, color, buttonx, buttony, buttonwidth, buttonheight, size = "small"):
    textSurf, textRect = text_objects(msg,color,size)
    textRect.center = ((buttonx +(buttonwidth/2)), buttony + (buttonheight/2)) #hvar er miðja takkans
    gameDisplay.blit(textSurf, textRect)

def message_to_screen(msg,color, y_displace = 0, size = "small"):
    textSurf, textRect = text_objects(msg,color,size)
    textRect.center = (int(display_width / 2), int(display_height / 2)+y_displace)
    gameDisplay.blit(textSurf, textRect)


def game_controls():
    gcont = True

    while gcont:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Leiðbeiningar",green,-200,size="large")
        message_to_screen("Leikmaður 1: Örvartakkar til að hreyfa leikmann ",black,-100)
        message_to_screen("Leikmaður 2: A, D og W til að hreyfa leikmann",black,-50)
        message_to_screen("Fyrirkomulagið er þannig að leikmaðurinn með fleiri mörk",black,0)
        message_to_screen("skoruð þegar leiktíminn rennur úr vinnur.",black,50)
        message_to_screen("Til þess að verða heimsmeistari þarf leikmaður að vinna 3 leiki",black,100)

        button1("Spila", 150,500,100,50, green, light_green, action = "Spila")
        button1("Til baka", 50,50,100,50, yellow, light_yellow, action = "Til baka")
        button1("Hætta", 550,500,100,50, red, light_red, action = "Hætta")


        pygame.display.update()

        clock.tick(15)

def velja_leikmann1():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu landslið",blue,-100,size="large")
        message_to_screen("Leikmaður 1, veldu þér landslið",black,0,size="medium")

        button1("Argentína", 50,500,125,50, BLUE, light_BLUE, action = "Argentína1")
        button1("Ísland", 250,500,125,50, blue, light_blue, action = "Ísland1")
        button1("Króatía", 450,500,125,50, red, light_red, action = "Króatía1")
        button1("Nígería", 650,500,125,50, green, light_green, action = "Nígería1")

        button1("Til baka", 50,50,100,50, yellow, light_yellow, action = "Til baka")
        button1("Hætta", 650,50,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_leikmann1 til baka til Client')
            break

        pygame.display.update()

        clock.tick(15)

def velja_leikmann2():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu landslið",blue,-100,size="large")
        message_to_screen("Leikmaður 2, veldu þér landslið",black,0,size="medium")

        button1("Argentína", 50,500,125,50, BLUE, light_BLUE, action = "Argentína2")
        button1("Ísland", 250,500,125,50, blue, light_blue, action = "Ísland2")
        button1("Króatía", 450,500,125,50, red, light_red, action = "Króatía2")
        button1("Nígería", 650,500,125,50, green, light_green, action = "Nígería2")

        button1("Til baka", 50,50,100,50, yellow, light_yellow, action = "Til baka")
        button1("Hætta", 650,50,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_leikmann2 til baka til Client')
            break

        pygame.display.update()

        clock.tick(15)

def velja_argentina1():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann",blue,-100,size="large")

        button("Lionel Messi", 250,350,300,50, "Argentina", 'P1', BLUE, light_BLUE, action = "Velja leikmann2")
        button("Sergio Aguero", 250,450,300,50, "Argentina", 'P1', BLUE, light_BLUE, action = "Velja leikmann2")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann1")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_argentina1 til baka til Client')
            break

        gameDisplay.blit(messi, (600, 300))
        gameDisplay.blit(aguero, (600, 400))

        pygame.display.update()

        clock.tick(15)

def velja_argentina2():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann2",blue,-100,size="large")

        button("Lionel Messi", 250,350,300,50, "Argentina", 'P2', BLUE, light_BLUE, action = "Hætta")
        button("Sergio Aguero", 250,450,300,50, "Argentina", 'P2', BLUE, light_BLUE, action = "Hætta")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann2")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_argentina2 til baka til Client')
            break

        gameDisplay.blit(messi, (600, 300))
        gameDisplay.blit(aguero, (600, 400))

        pygame.display.update()

        clock.tick(15)

def velja_island1():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann",blue,-100,size="large")

        button("Gylfi Sigurdsson", 250,350,325,50, "Island", 'P1', blue, light_blue, action = "Velja leikmann2")
        button("Johann Berg Gudmundsson", 250,450,325,50,  "Island", 'P1', blue, light_blue, action = "Velja leikmann2")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann1")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_island1 til baka til Client')
            break

        gameDisplay.blit(gylfi, (600, 300))
        gameDisplay.blit(johann, (600, 400))

        pygame.display.update()

        clock.tick(15)

def velja_island2():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann2",blue,-100,size="large")

        button("Gylfi Sigurdsson", 250,350,325,50,  "Island", 'P2', blue, light_blue, action = "Hætta")
        button("Johann Berg Gudmundsson", 250,450,325,50,  "Island", 'P2', blue, light_blue, action = "Hætta")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann2")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('Til baka til Client velja_island2')
            break

        gameDisplay.blit(gylfi, (600, 300))
        gameDisplay.blit(johann, (600, 400))

        pygame.display.update()

        clock.tick(15)

def velja_kroatia1():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann",blue,-100,size="large")

        button("Luka Modric", 250,350,300,50, "Kroatia", 'P1', red, light_red,  action = "Velja leikmann2")
        button("Mario Mandukic", 250,450,300,50, "Kroatia", 'P1', red, light_red,  action = "Velja leikmann2")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann1")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_kroatia1 til baka til Client')
            break

        gameDisplay.blit(modric, (600, 300))
        gameDisplay.blit(mandzukic, (600, 400))


        pygame.display.update()

        clock.tick(15)

def velja_kroatia2():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann2",blue,-100,size="large")

        button("Luka Modric", 250,350,300,50, "Kroatia", 'P2', red, light_red,  action = "Hætta")
        button("Mario Mandukic", 250,450,300,50, "Kroatia", 'P2', red, light_red,  action = "Hætta")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann2")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_kroatia2 til baka til Client')
            break

        gameDisplay.blit(modric, (600, 300))
        gameDisplay.blit(mandzukic, (600, 400))

        pygame.display.update()

        clock.tick(15)

def velja_nigeria1():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann",blue,-100,size="large")

        button("Alex Iwobi", 250,350,300,50, "Nigeria", 'P1', green, light_green,  action = "Velja leikmann2")
        button("Victor Moses", 250,450,300,50, "Nigeria", 'P1', green, light_green,  action = "Velja leikmann2")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann1")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('velja_nigeria1 til baka til Client')
            break

        gameDisplay.blit(iwobi, (600, 300))
        gameDisplay.blit(moses, (600, 400))
        pygame.display.update()

        clock.tick(15)

def velja_nigeria2():
    leikm = True

    while leikm:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Veldu leikmann2",blue,-100,size="large")

        button("Alex Iwobi", 250,350,300,50, "Nigeria", 'P2', green, light_green,  action = "Hætta")
        button("Victor Moses", 250,450,300,50, "Nigeria", 'P2', green, light_green, action = "Hætta")

        button1("Til baka", 50,100,100,50, yellow, light_yellow, action = "Velja leikmann2")
        button1("Hætta", 650,100,100,50, red, light_red, action = "Hætta")
        if haetta == 'Hætta':
            #print ('Til baka til Client')
            break

        gameDisplay.blit(iwobi, (600, 300))
        gameDisplay.blit(moses, (600, 400))

        pygame.display.update()

        clock.tick(15)



def button(text, x, y, width, height, nation, thing, inactive_color, active_color, action = None):
    cur = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    global haetta
    leikmenn = []
    open('leikmenn1.txt', 'w').close()

    file = open('leikmenn1.txt', 'w')

    if click and thing == 'P1':
        global player1_nation
        player1_nation = nation
        global player1_name
        player1_name = text

    if click and thing == 'P2':
        global player2_nation
        player2_nation = nation
        global player2_name
        player2_name = text

        leikmenn.append(player1_nation)
        leikmenn.append(player1_name)
        leikmenn.append(player2_nation)
        leikmenn.append(player2_name)

        for thing in leikmenn:
            #print(thing)
            file.write(thing+'\n')
        file.close()



    if x + width > cur[0] > x and y + height > cur[1] > y:
        pygame.draw.rect(gameDisplay, active_color, (x,y,width,height))
        if click[0] == 1 and action != None:
            if action == "Hætta":
                haetta='Hætta'
                return
            if action == "Leiðbeiningar":
                game_controls()
            if action == "Spila":
                gameLoop()
            if action == "Til baka":
                introo.game_intro()
            if action == "Velja leikmann1":
                velja_leikmann1()
            if action == "Argentína1":
                velja_argentina1()
            if action == "Ísland1":
                velja_island1()
            if action == "Króatía1":
                velja_kroatia1()
            if action == "Nígería1":
                velja_nigeria1()
            if action == "Velja leikmann2":
                velja_leikmann2()
            if action == "Argentína2":
                velja_argentina2()
            if action == "Ísland2":
                velja_island2()
            if action == "Króatía2":
                velja_kroatia2()
            if action == "Nígería2":
                velja_nigeria2()

    else:
        pygame.draw.rect(gameDisplay, inactive_color, (x,y,width,height))

    text_to_button(text,black, x,y,width, height)

def button1(text, x, y, width, height, inactive_color, active_color, action = None):
    cur = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    if x + width > cur[0] > x and y + height > cur[1] > y:
        pygame.draw.rect(gameDisplay, active_color, (x,y,width,height))
        if click[0] == 1 and action != None:
            if action == "Hætta":
                pygame.quit()
                quit()
                classmain.main()

            if action == "Leiðbeiningar":
                game_controls()
            if action == "Spila":
                gameLoop()
            if action == "Til baka":
                introo.game_intro()
            if action == "Velja leikmann1":
                velja_leikmann1()
            if action == "Argentína1":
                velja_argentina1()
            if action == "Ísland1":
                velja_island1()
            if action == "Króatía1":
                velja_kroatia1()
            if action == "Nígería1":
                velja_nigeria1()
            if action == "Velja leikmann2":
                velja_leikmann2()
            if action == "Argentína2":
                velja_argentina2()
            if action == "Ísland2":
                velja_island2()
            if action == "Króatía2":
                velja_kroatia2()
            if action == "Nígería2":
                velja_nigeria2()

    else:
        pygame.draw.rect(gameDisplay, inactive_color, (x,y,width,height))

    text_to_button(text,black, x,y,width, height)

class introo():

    def game_intro():

        intro = True
        gameDisplay.blit(fifa, (0, 0))

        while intro:
            for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        quit()

                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_c:
                            intro = False
                        elif event.key == pygame.K_q:

                            pygame.quit()
                            quit()

            message_to_screen("Ísland á HM",blue,-200,size="large")
            message_to_screen("Velkominn í Ísland á HM.",black,-100)
            message_to_screen("Þetta er þitt tækifæri til að upplifa HM í sumar.",black,-50)
            message_to_screen("Veldi þér landslið og leikmann og skemmtu þér vel.",black,0)


            button1("Spila", 100,500,100,50, green, light_green, action = "Spila")
            button1("Leiðbeiningar", 300,500,200,50, yellow, light_yellow, action = "Leiðbeiningar")
            button1("Hætta", 600,500,100,50, red, light_red, action = "Hætta")
            button1("Velja leikmann", 300,400,200,50, blue, light_blue, action = "Velja leikmann1")
            if haetta == 'Hætta':
                #print ('Til baka til Client')
                break




            pygame.display.update()

            clock.tick(15)



global haetta
haetta = 'hætta1'
introo.game_intro()
