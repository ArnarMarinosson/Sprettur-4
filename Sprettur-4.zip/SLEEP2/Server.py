import socket
import select
import sys
import time
import random

global Player1Wins, Player2Wins
Player1Wins = 0
Player2Wins = 0

class server():

    def __init__(self, team, playername):
        self.team = ''
        self.playername = ''
        Player1Wins = 0
        Player2Wins = 0

    def getPlayerInfo(self, c, c2):
        while True:
            buf = c2.recv(1024)
            msg = buf.decode('utf-8')
            print(msg)

            break


    def getResults(self, c, c2):
        self.c = c
        self.c2 = c2

        while True:
            '''Game 1'''
            buf = self.c2.recv(1024)
            msg = buf.decode('utf-8')
            print('Score Game 1:')
            print(msg)
            Game = Results(msg)
            Game.WhoWon()
            print('leikjastada')
            WinString = str(Player1Wins) + str(Player2Wins)
            print (WinString)
            c.send(bytes(WinString, 'utf-8'))
            # .......... Senda winner playerWins til ballboys til að birta ..........

            '''Game 2'''
            buf = self.c2.recv(1024)
            msg = buf.decode('utf-8')
            print('Score Game 2:')
            print(msg)
            Game = Results(msg)
            Game.WhoWon()
            print('leikjastada')
            WinString = str(Player1Wins) + str(Player2Wins)
            print (WinString)
            c.send(bytes(WinString, 'utf-8'))

            '''Game 3'''
            buf = self.c2.recv(1024)
            msg = buf.decode('utf-8')
            print('Score Game 3:')
            print(msg)
            Game = Results(msg)
            Game.WhoWon()
            print('leikjastada')
            WinString = str(Player1Wins) + str(Player2Wins)
            print (WinString)
            #c.send(bytes(WinString, 'utf-8'))

            ''' Athugum nú eftir hvern leik hvort annar hvor leikmaður hefur unnið 3 leiki og því unnið HM '''

            if Player1Wins == 3:
                Winner = 'Congratulations Player1 you won the World Cup'
                c.send(bytes(Winner, 'utf-8'))
            elif Player2Wins == 3:
                Winner = 'Congratulations Player2 you won the World Cup'
                c.send(bytes(Winner, 'utf-8'))
            else:
                c.send(bytes(WinString, 'utf-8'))

                '''Game 4'''
                buf = self.c2.recv(1024)
                msg = buf.decode('utf-8')
                print('Score Game 4:')
                print(msg)
                Game = Results(msg)
                Game.WhoWon()
                print('leikjastada')
                WinString = str(Player1Wins) + str(Player2Wins)
                print (WinString)
                #c.send(bytes(WinString, 'utf-8'))

            if Player1Wins == 3:
                Winner = 'Congratulations Player1 you won the World Cup'
                c.send(bytes(Winner, 'utf-8'))
            elif Player2Wins == 3:
                Winner = 'Congratulations Player2 you won the World Cup'
                c.send(bytes(Winner, 'utf-8'))
            else:
                c.send(bytes(WinString, 'utf-8'))

                '''Game 5'''
                buf = self.c2.recv(1024)
                msg = buf.decode('utf-8')
                print('Score Game 5:')
                print(msg)
                Game = Results(msg)
                Game.WhoWon()
                print('leikjastada')
                WinString = str(Player1Wins) + str(Player2Wins)
                print (WinString)
                c.send(bytes(WinString, 'utf-8'))

            if Player1Wins == 3:
                Winner = 'Congratulations Player1 you won the World Cup'
                c.send(bytes(Winner, 'utf-8'))
            elif Player2Wins == 3:
                Winner = 'Congratulations Player2 you won the World Cup'
                c.send(bytes(Winner, 'utf-8'))

            break


class Results():

    def __init__(self, GameXinfo):
        self.info = GameXinfo

    def WhoWon(self):
        global Player1Wins, Player2Wins

        ListOfNumbers = []
        for line in self.info:
            for number in line:
                ListOfNumbers.append(number)

        print(ListOfNumbers)
        player1Goals = ListOfNumbers[0]
        player2Goals = ListOfNumbers[1]
        if int(player1Goals) < int(player2Goals):
            Winner = 'player2'
            Player2Wins += 1
        elif int(player1Goals) > int(player2Goals):
            Winner = 'player1'
            Player1Wins += 1
        elif int(player1Goals) == int(player2Goals):
            Winner = 'Draw'

        print('Wincount')
        print(Player1Wins, Player2Wins)
        return print('Winner is: ' + Winner)

def main():
    s = socket.socket(socket.AF_INET , socket. SOCK_STREAM)
    s2 = socket.socket(socket.AF_INET , socket. SOCK_STREAM)
    port = 3333
    port2 = 3111

    cnt=0
    print('test0')
    try:
        s.bind (('',port))
        s2.bind (('',port2))
    except socket.error as msg:
        print( 'Bind failed - aborting' )
        sys.exit ()

    s.listen (5)
    s2.listen (5)


    while True:
        c,addr = s.accept()
        c2,addr2 = s2.accept()

        print('New connection:', addr)
        print('New connection:', addr2)

        print('test2')
        serv = server(c, c2)
        serv.getPlayerInfo(c, c2)
        print('test3')
        serv.getResults(c, c2)


    s.close()
    s2.close()


if __name__ == '__main__':
    main()
